--Step 1 : Check for the record counts for imported file--

select * from [My Agro].[dbo].[Senegal_CRS_29_Dec_17]--117

select * from [My Agro Unique files].[dbo].[Senegal_CRS_29Dec]--694

select *
into [My Agro].[dbo].[Senegal_CRS_29_Dec_17_v1]
from [My Agro].[dbo].[Senegal_CRS_29_Dec_17] where [Client-id] is not null

--Step 2 : Add row number and convert received date to mm/dd/yyyy formats--

select * from [My Agro].[dbo].[Senegal_CRS_29_Dec_17_v1]--113

select *, ROW_NUMBER() OVER(ORDER BY [client-id] ASC) AS Row,
convert(varchar(24),cast([received_on] as date),101) Received_Date
into [My Agro].[dbo].[CRS_29_Dec_17]
from [My Agro].[dbo].[Senegal_CRS_29_Dec_17_v1]--113

--Step 3 : Remove Duplicates from source file --

select count([Client-id]),[Client-id]
from [My Agro].[dbo].[CRS_29_Dec_17]
group by [Client-id]
having count([Client-id]) > 1 ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into CRS_Distinct_Values
from [CRS_29_Dec_17] 
group  by [client-id] 


Select *
into CRS_Distinct_Records
from [CRS_29_Dec_17]
where [client-id] not in (Select [client-id] from CRS_Distinct_Values) -- use this file for next step

Select *
into CRS_Dups_from_source_file
from [CRS_29_Dec_17]
where [client-id] in (Select [client-id] from CRS_Distinct_Values) -- export the file and log it as a bug 

--Step 4 : Remove Duplicates from file which are updated in previous loads--

select count([client-id]),[client-id]
from CRS_Distinct_Records
group  by [client-id] 
having count([client-id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into CRS_Distinct_Values_wrt_report
from CRS_Distinct_Records 
group  by [client-id] 


Select *
into CRS_Distinct_Records_wrt_report --- use this file for next step
from CRS_Distinct_Records
where [client-id] not in (Select [Client Code] from CRS_Distinct_Values_wrt_report)

Select *
into CRS_Dups_from_reports
from CRS_Distinct_Records
where [client-id] in (Select [Client Code] from CRS_Distinct_Values_wrt_report) -- export the file and log it as a bug 

--Step 5 : Discard records out of given date range--

/* Note :  Source file to use here will depend on the output of previous steps */

select * from Senegal_Distinct_Records_wrt_report

SELECT * 
into Senegal_Final_14_12_17
FROM Senegal_Distinct_Records_wrt_report
WHERE Received_Date >= '12/25/2017'---  if no duplicates go to next step and use the source file from previous step

/* Note :  The Received_Date depends on the daily import date. You need to change this as per the requirement. */

--Step 6 : Create Client file --

select * from [My Agro].[dbo].Senegal_Distinct_Records_wrt_report ----113

select 
[Client-id],[Sf_id] as Client_Sf_Id,[Zone],[Village],[Members],[Men],[Women],[Silc],[Leaders-name],[Leaders-phone],
cast(null as varchar(max)) as Zone_SF_Id, cast(null as varchar(max)) as Village_SF_Id,row
into [My Agro].[dbo].[Clients_CRS_29_Dec_17]
from [My Agro].[dbo].Senegal_Distinct_Records_wrt_report  --113

select * from  [My Agro].[dbo].[Clients_CRS_29_Dec_17]--113



--Step 7 : Update village Id and Client Id's in Client file --

/* Note  :  We need export the Village data(Village Name, SF Id and Village Code) 
            from SF and need to import file in SQL. Try to populate Village Sf Id's based 
			on village code in source file if you are not getting data then try with village name */ 

update [Clients_CRS_29_Dec_17]
set Village_SF_Id = a.id
from [dbo].[Village_SF] a
where a.Village_Code__c = [Clients_CRS_29_Dec_17].[Village] --2660


select * from Clients_Senegal_14_Dec_17_2988 where Village_SF_Id is null

/* Note  :  We need export the Clients data(Name and SF Id) 
            from SF and need to import file in SQL */ 

update [Clients_CRS_29_Dec_17]
set Client_SF_Id =  a.[Client ID]
from [dbo].CL_SF1_27_11_17 a
where a.[Client Code] = [Clients_CRS_29_Dec_17].Client_Id

/* Check Village_SF_Id and Client_SF_Id for NULL values if 
   this is the case log a bug for blqank villages*/

select * from [Clients_CRS_29_Dec_17] where Client_SF_Id is null

select * from [Clients_CRS_29_Dec_17] where Village_SF_Id is null


--Step 8 : Create Packet files  --

/* Note : use the file created after deduplication of records  */ 

select * from Senegal_Distinct_Records_wrt_report

/* Bissap (Vimto) and Pasteque (Kaolack) have packet size problems problem.
Senegal enrollment: columns named "packet7-size" and "packet8-size"
CRS enrollment: "Packet6-size" and "Packet7-size"
the Bissap packets should all be .225 and the Pasteque should all be .01. */

update Senegal_Distinct_Records_wrt_report
set [packet6-Size] = '0.225'
from Senegal_Distinct_Records
where [packet6-type] = 'Vimto' 

update Senegal_Distinct_Records_wrt_report
set [packet7-Size] = '0.01'
from Senegal_Distinct_Records
where [packet7-type] = 'Kaolack'


SELECT [client-id]
      ,[packet1-SF]
      ,[packet2-sf]
      ,[packet3-sf]
      ,[packet4-sf]
      ,[packet5-sf]
      ,[packet6-sf]
      ,[packet7-sf]
      ,[packet8-sf]
      ,[packet9-sf]
FROM [My Agro].[dbo].Senegal_Distinct_Records_wrt_report ----Create file and load in talend

SELECT [client-id]
      ,[packet1-Size]
      ,[packet2-Size]
      ,[packet3-Size]
      ,[packet4-Size]
      ,[packet5-Size]
      ,[packet6-Size]
      ,[packet7-Size]
      ,[packet8-Size]
      ,[packet9-Size]
FROM [My Agro].[dbo].Senegal_Distinct_Records_wrt_report ----Create file and load in talend

-Step 9 : Create Savings Goal and Goal Items files  --

/* Note : Import the packet file created in talend and use that as a source.
          Export data for pricebook and product report and import the files in SF
		  Use the reports for populating related SF'Ids */ 

select * from [dbo].CRS_Load_Packet_Info 

update Senegal_Load_Packet_Info
set Packet1_SF = 'a0S0J00000RdEmt'
where Packet1_SF = 'a0M0J00001BhbCk'

alter table CRS_Load_Packet_Info
add Product_Id varchar(max),
Product_Name varchar(max),
Client_SF_Id varchar(max),
Pricebook_Id varchar(max),
Saving_Goal_Name varchar(max),
Completed_On varchar(max)

--Step 7 : Update related SF Id's --

select * from [dbo].[Product Types with Pricebook_21-11-17]

select * from [dbo].[Product_Type_Report_21-11-17]

-- update Client_SF_Id
update [dbo].CRS_Load_Packet_Info
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF1_27_11_17] b
where  [dbo].CRS_Load_Packet_Info.client_id = b.[Client Code]


select * from Senegal_Load_Packet_Info where Client_SF_Id is null

-- update Pricebook_Id
update [dbo].CRS_Load_Packet_Info
set Pricebook_Id = c.[Price Book: Record ID]
from [dbo].[Product Types with Pricebook_21-11-17] c
where [dbo].CRS_Load_Packet_Info.Packet1_SF  = c.[Product Type: ID]

-- update Product_Name
update [dbo].CRS_Load_Packet_Info
set Product_Name = c.[Product Name]
from [dbo].[Product_Type_Report_21-11-17] c
where [dbo].CRS_Load_Packet_Info.Packet1_SF = c.[Product Type ID] 

-- update Saving_Goal_Name
update [dbo].CRS_Load_Packet_Info
set Saving_Goal_Name=CONCAT(client_id,'-2018-',Product_Name)
where Product_Name is not null and Client_SF_Id is not null

select distinct Saving_Goal_Name from CRS_Load_Packet_Info

-- update ProductId

update CRS_Load_Packet_Info
set Product_Id = c.[Product ID]
from [dbo].[Product_Type_Report_21-11-17] c
where CRS_Load_Packet_Info.Packet1_SF = c.[Product Type ID]---5945

-- update Completed_On
update  CRS_Load_Packet_Info
set Completed_On = convert(varchar(24),cast(b.Completed_time as date),101)
from [dbo].[Senegal_CRS_29_Dec_17] b -------- This file is from step 1
where CRS_Load_Packet_Info.client_id = b.[client-id]

-- Check if Completed_on date is of future then convert it to date before import date
select *
from CRS_Load_Packet_Info
where completed_on > '12/27/2017'

update CRS_Load_Packet_Info
set completed_on = '12/26/2017'
where completed_on > '12/27/2017'

--Step 10 : Remove records with Packet_Size = 0 goal items --

/* Note : Source file depends on output of previous file */

select *
into CRS_Load_PacketSize_0
from [CRS_Packet_5Jan]
where packet1_size = '0' ---  log it as a bug

select *
into CRS_Load_PacketSize_not_0
from CRS_Load_Packet_Info
where packet1_size != '0' -- use this file for load



--Step 11 : Dedup savings goals --

select * from Senegal_Load_Packet_Info


select count(Saving_Goal_Name),Saving_Goal_Name
from CRS_Load_PacketSize_not_0 
group  by Saving_Goal_Name 
having count(Saving_Goal_Name) > 1 ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into CRS_SG_14Dec_2017 
from CRS_Load_PacketSize_not_0 

select min(Row) as rw 
into CRS_SG_Load_Distinct_values
from CRS_SG_14Dec_2017 
group  by client_id 

Select *
into CRS_SG_14Dec_2017_Distinct_Records
from CRS_SG_14Dec_2017
where client_id not in (Select client_id from CRS_SG_Load_Distinct_values) -- use this file for load

Select *
into CRS_Dups_from_SG
from CRS_SG_14Dec_2017
where client_id in (Select client_id from CRS_SG_Load_Distinct_values) -- export the file and log it as a bug 


--Step 12 : Dedup goal items --

select count(concat(Saving_Goal_Name,Packet1_SF)),concat(Saving_Goal_Name,Packet1_SF) 
from CRS_Load_PacketSize_not_0 
group  by concat(Saving_Goal_Name,Packet1_SF)
having count(concat(Saving_Goal_Name,Packet1_SF)) > 1

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into CRS_GI_14dec_2017 
from CRS_Load_PacketSize_not_0 

select min(Row) as rw 
into CRS_GI_Load_Distinct_values
from CRS_GI_14dec_2017 
group  by client_id 

Select *
into CRS_SG_14Dec_2017_Distinct_Records
from CRS_GI_14dec_2017
where client_id not in (Select client_id from CRS_GI_Load_Distinct_values) -- use this file for load

Select *
into CRS_Dups_from_GI
from CRS_GI_14dec_2017
where client_id in (Select client_id from CRS_GI_Load_Distinct_values) -- export the file and log it as a bug 

--Step 13 : Create program file --

alter table Senegal_Distinct_Records_wrt_report
add [Program Name] varchar(max),
completed_on varchar(max),
Village_SF_Id varchar(max)


update Senegal_Distinct_Records_wrt_report
set [Program Name] = concat('CRS-',[client-Id])

update Senegal_Distinct_Records_wrt_report
set completed_on = convert(varchar(24),cast(Completed_time as date),101)

update Senegal_Distinct_Records_wrt_report
set [Program Name] = concat('CRS-',[client-Id])


update Senegal_Distinct_Records_wrt_report
set Village_SF_Id = a.id
from [dbo].[Village_SF] a
where a.Village_Code__c = [CRS_5Jan].[Village] --2660








