--Step 1 : Check for the record counts for imported file--

select * from  [dbo].[Stromme_Payments_Upload_19Dec_17] ---137


--Step 2 : Add row number and convert received date to mm/dd/yyyy formats--

select *, ROW_NUMBER() OVER(ORDER BY [Client ID] ASC) AS Row,
convert(varchar(24),cast([Date Received] as date),101) Received_Date
into Payments_19_Dec_17
from [Stromme_Payments_Upload_19Dec_17]  ---137

--Step 3 : Remove duplicates based on Clients'Ids --

select count([Client ID]),[Client ID]
from [Stromme_Payments_Upload_19Dec_17]
group by [Client ID]
having count([Client ID]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into pay_Distinct_Values
from Payments_19_Dec_17 
group  by [Client ID]  ---116

Select Payments_19_Dec_17.*
into Pay_Distinct_Records
from Payments_19_Dec_17
where Row not in (Select rw from pay_Distinct_Values)  --- use created file in next step


Select Payments_19_Dec_17.*
into Payment_Duplicates
from Payments_19_Dec_17
where Row  in (Select rw from pay_Distinct_Values)  --- log it as bug

-- Step 4 : Remove duplicates based on voucher codes --

select count([Scratch Code]),[Scratch Code]
from Pay_Distinct_Records
group by [Scratch Code]
having count([Scratch Code]) > 1  --- if no duplicates go to next step and use the source file from previous step 

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Pay_Distinct_ValuesV1
from Pay_Distinct_Records 
group  by [Client ID]  ---116

Select Pay_Distinct_Records.*
into Pay_Distinct_RecordsV1
from Pay_Distinct_Records
where Row not in (Select rw from Pay_Distinct_ValuesV1)  --- use created file 

Select Pay_Distinct_Records.*
into Pay_Dups_VoucherCodes
from Pay_Distinct_Records
where Row  in (Select rw from Pay_Distinct_ValuesV1)  --- log it as bug

----------------------------------------------------

