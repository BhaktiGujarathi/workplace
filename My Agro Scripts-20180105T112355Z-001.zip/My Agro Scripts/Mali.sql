--Step 1 : Check for the record counts for imported file--

select * from [My Agro].[dbo].[Mali_12Dec_2017] ---6656

--Step 2 : Add row number and convert received date to mm/dd/yyyy formats--

select *, convert(varchar(24),cast(received_on as date),101) as Received_Date,
ROW_NUMBER() OVER(ORDER BY [client-id] ASC) AS Row
into Mali_Load_12_12_17
from [Mali_12Dec_2017]  ----6656

--Step 3 : Remove Duplicates from source file --

select count([client-id]),[client-id]
from Mali_Load_12_12_17 
group  by [client-id] 
having count([client-id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Mali_Distinct_Values
from Mali_Load_12_12_17 
group  by [client-id] 


Select *
into Mali_Distinct_Records
from Mali_Load_12_12_17
where [client-id] not in (Select [client-id] from Mali_Distinct_Values) -- use this file for next step

Select *
into Mali_Dups_from_source_file
from Mali_Load_12_12_17
where [client-id] in (Select [client-id] from Mali_Distinct_Values) -- export the file and log it as a bug 


--Step 4 : Remove Duplicates from file which are updated in previous loads--

select count([client-id]),[client-id]
from Mali_Distinct_Records
group  by [client-id] 
having count([client-id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Mali_Distinct_Values_wrt_report
from Mali_Distinct_Records 
group  by [client-id] 


Select *
into Mali_Distinct_Records_wrt_report --- use this file for next step
from Mali_Distinct_Records
where [client-id] not in (Select [Client Code] from Mali_Distinct_Values_wrt_report)

Select *
into Mali_Dups_from_reports
from Mali_Distinct_Records
where [client-id] in (Select [Client Code] from Mali_Distinct_Values_wrt_report) -- export the file and log it as a bug 


--Step 5 : Discard records out of given date range--

/* Note :  Source file to use here will depend on the output of previous steps */
select * from Mali_Distinct_Records_wrt_report

SELECT * 
into Mali_Final_12_12_17
FROM Mali_Distinct_Records_wrt_report
WHERE Received_Date >= '12/25/2017'---  if no duplicates go to next step and use the source file from previous step

/* Note :  The Received_Date depends on the daily import date. You need to change this as per the requirement. */


--Step 6 : Create Client file --

select a.[client-id] as Client_Id,cast(null as varchar(max)) as Client_SF_Id,
a.[first_name] as First_Name,a.[last_name] as Last_Name ,
a.phone as Phone,
case
When a.gender='M' then 'Male'
When a.gender='F' then 'Female'
When a.gender='Male' then 'Male'
When a.gender='Female' then 'Female'
else '' End As Gender,
[village], cast(Null as varchar(max)) as Village_SF_Id ,
convert(varchar(24),cast(a.completed_time as date),101) as Completed_On,completed_time,
[received_on],convert(varchar(24),cast(a.[received_on] as date),101) as Received_Date,row
into Clients_Mali_12_12_17
from Mali_Final_12_12_17 a 


--Step 7 : Update village Id and Client Id's in Client file --

/* Note  :  We need export the Village data(Village Name, SF Id and Village Code) 
            from SF and need to import file in SQL. Try to populate Village Sf Id's based 
			on village code in source file if you are not getting data then try with village name */ 

update Clients_Mali_12_12_17 
set Village_SF_Id = a.id
from [dbo].[Village_SF] a
where a.Village_Code__c = Clients_Mali_12_12_17.village 
  
/* Note  :  We need export the Clients data(Name and SF Id) 
            from SF and need to import file in SQL */ 

update Clients_Mali_12_12_17
set Client_SF_Id =  a.[Client ID]
from [dbo].[CL_SF1_27_11_17] a
where a.[Client Code] = Clients_Mali_12_12_17.Client_Id

/* Check Village_SF_Id and Client_SF_Id for NULL values if 
   this is the case log a bug for blqank villages*/

select * from Clients_Mali_12_12_17 where Client_SF_Id is null

select * from Clients_Mali_12_12_17 where Village_SF_Id is null

--Step 8 : Create Packet files  --

/* Note : use the file created after deduplication of records  */ 

SELECT [client-id]
      ,[packet1-SF]
      ,[packet2-sf]
      ,[packet3-sf]
      ,[packet4-sf]
      ,[packet5-sf]
      ,[packet6-sf]
      ,[packet7-sf]
      ,[packet8-sf]
      ,[packet9-sf]
	  ,[packet10-sf]
	  ,[packet11-sf]
	  ,[packet12-sf]
	  ,[packet13-sf]
	  ,[packet14-sf]
FROM [My Agro].[dbo].Mali_Load_12_12_17 ----Create file and load in talend

SELECT [client-id]
      ,[packet1-Size]
      ,[packet2-Size]
      ,[packet3-Size]
      ,[packet4-Size]
      ,[packet5-Size]
      ,[packet6-Size]
      ,[packet7-Size]
      ,[packet8-Size]
      ,[packet9-Size]
	  ,[packet10-size]
	  ,[packet11-size]
	  ,[packet12-size]
	  ,[packet13-size]
	  ,[packet14-size]
FROM [My Agro].[dbo].Mali_Load_12_12_17 ----Create file and load in talend

--Step 9 : Create Savings Goal and Goal Items files  --

/* Note : Import the packet file created in talend and use that as a source.
          Export data for pricebook and product report and import the files in SF
		  Use the reports for populating related SF'Ids */ 

select * from [dbo].Mali_Load_Packet_Info 

update Mali_Load_Packet_Info
set Packet1_SF = 'a0S0J00000RdEmt'
where Packet1_SF = 'a0M0J00001BhbCk'

alter table Mali_Load_Packet_Info
add Product_Id varchar(max),
Product_Name varchar(max),
Client_SF_Id varchar(max),
Pricebook_Id varchar(max),
Saving_Goal_Name varchar(max),
Completed_On varchar(max)

--Step 7 : Update related SF Id's --

select * from [dbo].[Product Types with Pricebook_21-11-17]

select * from [dbo].[Product_Type_Report_21-11-17]

-- update Client_SF_Id
update [dbo].Mali_Load_Packet_Info
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF1_27_11_17] b
where  [dbo].Mali_Load_Packet_Info.client_id = b.[Client Code]


select * from Mali_Load_Packet_Info where Client_SF_Id is null

-- update Pricebook_Id
update [dbo].Mali_Load_Packet_Info
set Pricebook_Id = c.[Price Book: Record ID]
from [dbo].[Product Types with Pricebook_21-11-17] c
where [dbo].Mali_Load_Packet_Info.Packet1_SF  = c.[Product Type: ID]

-- update Product_Name
update [dbo].Mali_Load_Packet_Info
set Product_Name = c.[Product Name]
from [dbo].[Product_Type_Report_21-11-17] c
where [dbo].Mali_Load_Packet_Info.Packet1_SF = c.[Product Type ID] 

-- update Saving_Goal_Name
update [dbo].Mali_Load_Packet_Info
set Saving_Goal_Name=CONCAT(client_id,'-2018-',Product_Name)
where Product_Name is not null and Client_SF_Id is not null

select distinct Saving_Goal_Name from Mali_Load_Packet_Info

-- update ProductId

update Mali_Load_Packet_Info
set Product_Id = c.[Product ID]
from [dbo].[Product_Type_Report_21-11-17] c
where Mali_Load_Packet_Info.Packet1_SF = c.[Product Type ID]---5945

-- update Completed_On
update  Mali_Load_Packet_Info
set Completed_On = convert(varchar(24),cast(b.Completed_time as date),101)
from [dbo].[Mali_12Dec_2017] b -------- This file is from step 1
where Mali_Load_Packet_Info.client_id = b.[client-id]

-- Check if Completed_on date is of future then convert it to date before import date
select *
from Mali_Load_Packet_Info
where completed_on > '12/27/2017'

update Mali_Load_Packet_Info
set completed_on = '12/26/2017'
where completed_on > '12/27/2017'

--Step 10 : Remove records with Packet_Size = 0 goal items --

/* Note : Source file depends on output of previous file */

select *
into Mali_SG_12Dec_2017_PacketSize_0
from Mali_Load_Packet_Info
where packet1_size = '0' ---  log it as a bug

select *
into Mali_SG_12Dec_2017_PacketSize_not_0
from Mali_Load_Packet_Info
where packet1_size != '0' -- use this file for load




--Step 11 : Dedup savings goals --

select * from Mali_Load_Packet_Info


select count(Saving_Goal_Name),Saving_Goal_Name
from Mali_SG_12Dec_2017_PacketSize_not_0 --- File is from step 9
group  by Saving_Goal_Name 
having count(Saving_Goal_Name) > 1 ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into Mali_SG_12Dec_2017 
from Mali_SG_12Dec_2017_PacketSize_not_0 

select min(Row) as rw 
into Mali_SG_Load_Distinct_values
from Mali_SG_12Dec_2017 
group  by client_id 

Select *
into Mali_SG_12Dec_2017_Distinct_Records
from Mali_SG_12Dec_2017
where client_id not in (Select client_id from Mali_SG_Load_Distinct_values) -- use this file for load

Select *
into Mali_Dups_from_SG
from Mali_SG_12Dec_2017
where client_id in (Select client_id from Mali_SG_Load_Distinct_values) -- export the file and log it as a bug 



--Step 12 : Dedup goal items --

select count(concat(Saving_Goal_Name,Packet1_SF)),concat(Saving_Goal_Name,Packet1_SF) 
from Mali_SG_12Dec_2017_PacketSize_not_0 --- File is from step 9
group  by concat(Saving_Goal_Name,Packet1_SF)
having count(concat(Saving_Goal_Name,Packet1_SF)) > 1

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into Mali_GI_12Dec_2017 
from Mali_SG_12Dec_2017_PacketSize_not_0 

select min(Row) as rw 
into Mali_GI_Load_Distinct_values
from Mali_GI_12Dec_2017 
group  by client_id 

Select *
into Mali_GI_12Dec_2017_Distinct_Records
from Mali_GI_12Dec_2017
where client_id not in (Select client_id from Mali_GI_Load_Distinct_values) -- use this file for load

Select *
into Mali_Dups_from_GI
from Mali_GI_12Dec_2017
where client_id in (Select client_id from Mali_GI_Load_Distinct_values) -- export the file and log it as a bug 






