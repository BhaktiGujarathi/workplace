--Step 1 : Check for the record counts for imported file--

select * from [dbo].[lecentre_14Dec_2017]

--Step 2 : Add row number and convert received date to mm/dd/yyyy formats--

select count([deposit_ref]),[deposit_ref]
from [lecentre_14Dec_2017]
group by [deposit_ref]
having count([deposit_ref]) > 1 

/* If the above query gives you duplicates then only follow following steps */

select *, ROW_NUMBER() OVER(ORDER BY [deposit_ref] ASC) AS Row
into lecenter_14Dec_Load
from [lecentre_14Dec_2017]  ---441

select min(Row) as rw 
into lecenter_Distinct_Values
from lecenter_14Dec_Load
group  by [deposit_ref]  ---130

Select lecenter_14Dec_Load.*
into Lecenter_Distinct_Records
from lecenter_14Dec_Load
where Row not in (Select rw from lecenter_Distinct_Values)  --- use this file

Select lecenter_14Dec_Load.*
--into Lecenter_Dup_Records
from lecenter_14Dec_Load
where Row in (Select rw from lecenter_Distinct_Values)  --- log it as a bug

select * from Lecenter_Distinct_Records



