--Step 1 : Check for the record counts for imported file--

select * from [My Agro].[dbo].[Stromme_Enrollment_5_Dec_17] ---1151


--Step 2 : Create file for Stromee Gropus --

select  cast(Null as varchar(max)) as Program_SF_Id,
cast(Null as varchar(max)) as program_membership_start_date,
cast(Null as varchar(max)) as Client_SF_Id,
[group],
cast(Null as varchar(max)) as Village_SF_Id,
[id] as Client_Id,[village],[village-code],
[completed_time]
into [My Agro].[dbo].Stromme_Groups
from Stromme_Enrollment_5_Dec_17_Distinct_Records --1134

/* Note  :  We need export the Village data(Village Name, SF Id and Village Code) 
            from SF and need to import file in SQL. Try to populate Village Sf Id's based 
			on village code in source file if you are not getting data then try with village name */ 

-- update village Id
update Stromme_Groups
set Village_SF_Id = a.id
from [dbo].[Village_SF] a
where a.Village_Code__c = Stromme_Groups.[village-code] ---1133

/* Note  :  We need export the Clients data(Name and SF Id) 
            from SF and need to import file in SQL */ 

-- update Client_SF_Id 
update Stromme_Groups
set Client_SF_Id =  a.[Client ID]
from [dbo].[CL_SF1_27_11_17] a
where a.[Client Code] = Stromme_Groups.Client_Id

select * from Stromme_Groups where Client_SF_Id is null

/* Note  :  We need export the Program data(Name and SF Id) 
            from SF and need to import file in SQL */ 

-- update Program_SF_Id
select * from [dbo].[Program_sf]

update Stromme_Groups
set Program_SF_Id =  a.id
from [dbo].[Program_sf] a
where a.Name = Stromme_Groups.[group]--942

/* The CommCare export may not yet have the salesforce record id listed for "Pas de Groupe" and "Nouveau Groupe".  
Change this to "Stromme - Savings for Change".
select * from Stromme_Groups where [group]='Nouveau Groupe' */ 

update Stromme_Groups
set Program_SF_Id = 'a2Hb0000001RINy'
where ([group]='Nouveau Groupe' or [group]='Pas de groupe')
and Program_SF_Id is null --22

-- update  program_membership_start_date
update  Stromme_Groups
set program_membership_start_date = convert(varchar(24),cast(Completed_time as date),101)

select * from [My Agro].[dbo].Stromme_Groups where Village_SF_Id is null


--Step 3 : Create program membership file (dedup based on client Id) -- 
select * from [My Agro].[dbo].Stromme_Groups

select *,
ROW_NUMBER() OVER(ORDER BY [group] ASC) AS Row
into [My Agro].dbo.Stromme_Groups_Load
from [My Agro].[dbo].Stromme_Groups  ---1134

-- Dedup based on client Id
select count(Client_Id),Client_Id
from [My Agro].[dbo].Stromme_Groups
group by Client_Id
having count(Client_Id) > 1 ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into PM_Distinct_Values
from Stromme_Groups 
group  by [client-id] 


Select *
into PM_Distinct_Records
from Stromme_Groups
where [client-id] in (Select [Client Code] from PM_Distinct_Values) -- use this file for next step

Select *
into PM_Dup_Records
from Stromme_Groups
where [client-id] not in (Select [Client Code] from PM_Distinct_Values) -- export the file and log it as a bug 

--Step 3 : Create program membership file (dedup based on Group) -- 

/* Note :  Source file to use here will depend on the output of previous steps */

select * from [My Agro].[dbo].PM_Distinct_Records

select count([group]),[group]
from [My Agro].[dbo].PM_Distinct_Records
group by [group]
having count([group]) > 1  ----- if no duplicates go to next step and use the source file from previous step

select min(Row) as rw 
into PM_Groups_Distinct_Values
from [My Agro].dbo.PM_Distinct_Records 
group  by [group]  ---154

Select [My Agro].dbo.PM_Distinct_Records .*
into [My Agro].dbo.PM_Groups_Distinct_Records
from [My Agro].dbo.PM_Distinct_Records 
where Row in (Select rw from PM_Groups_Distinct_Values) ---Use this file for load

Select [My Agro].dbo.PM_Distinct_Records .*
into PM_Groups_Dup_Records
from [My Agro].dbo.PM_Distinct_Records 
where Row Not in (Select rw from PM_Groups_Distinct_Values) --- log it as a bug


--Step 4 : Create program file (dedup based on Group) -- 


select count([group]),[group]
from [My Agro].[dbo].Stromme_Groups
group by [group]
having count([group]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Program_Distinct_Values
from [My Agro].dbo.Stromme_Groups 
group  by [group]  ---154

Select [My Agro].dbo.Stromme_Groups .*
into [My Agro].dbo.Program_Distinct_Records
from [My Agro].[dbo].Stromme_Groups
where Row in (Select rw from Program_Distinct_Values) 


Select [My Agro].dbo.Stromme_Groups .*
into [My Agro].dbo.Program_Distinct_Records
from [My Agro].[dbo].Stromme_Groups
where Row in (Select rw from Program_Distinct_Values) 


--Step 5 : Update required SF Id's in program file -- 
select * from [My Agro].[dbo].Program_Distinct_Records ----155


DELETE FROM [My Agro].[dbo].Program_Distinct_Records
where ([group]='Nouveau Groupe' or [group]='Pas de groupe')


alter table [My Agro].[dbo].Program_Distinct_Records
add Program_SF_Id varchar(max),
completed_on varchar(max), 
Village_SF_Id1 varchar(max)

update [My Agro].[dbo].Program_Distinct_Records
set Program_SF_Id =  a.id
from [My Agro].[dbo].[Program_sf] a
where a.Name = [My Agro].[dbo].Program_Distinct_Records.[group]--153

update [My Agro].[dbo].Program_Distinct_Records
set Village_SF_Id1 = a.id
from [My Agro].[dbo].[Village_SF] a
where a.Village_Code__c = [My Agro].[dbo].Program_Distinct_Records.[village-code] --152

update [My Agro].[dbo].Program_Distinct_Records
set completed_on =   convert(varchar(24),cast(Completed_time as date),101)

























