select * from [My Agro].[dbo].[CRS_29_Dec_17_Prg]

--Step 1 : Check for the record counts for imported file--

select * from [dbo].[Stromme_19Dec_17]--948

--Step 2 : Add row number and convert received date to mm/dd/yyyy formats--

select *,convert(varchar(24),cast(received_on as date),101) as Received_Date,
ROW_NUMBER() OVER(ORDER BY [id] ASC) AS Row
into Stromme_Enrollment_19_Dec_17
from [Stromme_19Dec_17]   ---948


--Step 3 : Remove Duplicates from source file --

select count([id]),[id]
from Stromme_Enrollment_19_Dec_17 
group  by [id] 
having count([id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Stromme_Distinct_Values
from Stromme_Enrollment_19_Dec_17 
group  by [id] 


Select *
into Stromme_Distinct_Records
from Stromme_Enrollment_19_Dec_17
where [id] not in (Select [id] from Stromme_Distinct_Values) -- use this file for next step

Select *
into Stromme_Dups_from_source_file
from Stromme_Enrollment_19_Dec_17
where [id] in (Select [id] from Stromme_Distinct_Values) -- export the file and log it as a bug 


--Step 4 : Remove Duplicates from file which are updated in previous loads--

select count([id]),[id]
from Stromme_Distinct_Records
group  by [client-id] 
having count([id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Stromme_Distinct_Values_wrt_report
from Stromme_Distinct_Records 
group  by [client-id] 


Select *
into Stromme_Distinct_Records_wrt_report --- use this file for next step
from Stromme_Distinct_Records
where [client-id] not in (Select [Client Code] from Stromme_Distinct_Values_wrt_report)

Select *
into Stromme_Dups_from_reports
from Stromme_Distinct_Records
where [client-id] in (Select [Client Code] from Stromme_Distinct_Values_wrt_report) -- export the file and log it as a bug 

--Step 5 : Discard records out of given date range--

/* Note :  Source file to use here will depend on the output of previous steps */
select * from Stromme_Distinct_Records_wrt_report

SELECT * 
into Stromme_Final_19_12_17
FROM Stromme_Distinct_Records_wrt_report
WHERE Received_Date >= '12/25/2017'---  if no duplicates go to next step and use the source file from previous step

/* Note :  The Received_Date depends on the daily import date. You need to change this as per the requirement. */

--Step 6 : Create Client file --

select * from Stromme_Final_19_12_17

select a.[id] as Client_Id,cast(null as varchar(max)) as Client_SF_Id,
case
When a.gender='M' then 'Male'
When a.gender='F' then 'Female'
When a.gender='Male' then 'Male'
When a.gender='Female' then 'Female'
else '' End As Gender,
[village-code], cast(Null as varchar(max)) as Village_SF_Id ,
convert(varchar(24),cast(a.completed_time as date),101) as Completed_On,
convert(varchar(24),cast(a.[received_on] as date),101) as Received_Date,row
into Clients_Stromme_Enrollment_19_Dec_17
from [dbo].Stromme_Final_19_12_17 a --749

--Step 7 : Update village Id and Client Id's in Client file --

/* Note  :  We need export the Village data(Village Name, SF Id and Village Code) 
            from SF and need to import file in SQL. Try to populate Village Sf Id's based 
			on village code in source file if you are not getting data then try with village name */ 

update Clients_Stromme_Enrollment_19_Dec_17
set Village_SF_Id = a.id
from [dbo].[Village_SF] a
where a.Village_Code__c = Clients_Stromme_Enrollment_19_Dec_17.[village-code] ---748

/* Note  :  We need export the Clients data(Name and SF Id) 
            from SF and need to import file in SQL */ 

update Clients_Stromme_Enrollment_19_Dec_17
set Client_SF_Id =  a.[Client ID]
from [dbo].[CL_SF1_27_11_17] a
where a.[Client Code] = Clients_Stromme_Enrollment_19_Dec_17.Client_Id

/* Check Village_SF_Id and Client_SF_Id for NULL values if 
   this is the case log a bug for blqank villages*/

select * from Clients_Stromme_Enrollment_19_Dec_17 where Client_SF_Id is null

select * from Clients_Stromme_Enrollment_19_Dec_17 where Village_SF_Id is null

--Step 8 : Create Packet files  --

/* Note : use the file created after deduplication of records  */ 

select * from Stromme_Distinct_Values_wrt_report

/* Bissap (Vimto) and Pasteque (Kaolack) have packet size problems problem.
Senegal enrollment: columns named "packet7-size" and "packet8-size"
CRS enrollment: "Packet6-size" and "Packet7-size"
the Bissap packets should all be .225 and the Pasteque should all be .01. */

update Stromme_Distinct_Values_wrt_report
set [packet6-Size] = '0.225'
from Stromme_Distinct_Values_wrt_report
where [packet6-type] = 'Vimto' 

update Stromme_Distinct_Values_wrt_report
set [packet7-Size] = '0.01'
from Stromme_Distinct_Values_wrt_report
where [packet7-type] = 'Kaolack'


SELECT [id]
	,[packet-sf-1]
	,[packet-sf-2]
	,[packet-sf-3]
	,[packet-sf-4]
	,[packet-sf-5]
	,[packet-sf-6]
	,[packet-sf-7]
	,[packet-sf-8]
FROM [My Agro].[dbo].Stromme_Distinct_Values_wrt_report ----Create file and load in talend(3184)

SELECT [id]
	,[packet-size-1]
	,[packet-size-2]
	,[packet-size-3]
	,[packet-size-4]
	,[packet-size-5]
	,[packet-size-6]
	,[packet-size-7]
	,[packet-size-8]
FROM [My Agro].[dbo].Stromme_Distinct_Values_wrt_report ----Create file and load in talend 

--Step 9 : Create Savings Goal and Goal Items files  --

/* Note : Import the packet file created in talend and use that as a source.
          Export data for pricebook and product report and import the files in SF
		  Use the reports for populating related SF'Ids */ 

select * from [dbo].Stromme_Packet_Info

update Stromme_Packet_Info
set Packet1_SF = 'a0S0J00000RdEmt'
where Packet1_SF = 'a0M0J00001BhbCk'

alter table Stromme_Packet_Info
add Product_Id varchar(max),
Product_Name varchar(max),
Client_SF_Id varchar(max),
Pricebook_Id varchar(max),
Saving_Goal_Name varchar(max),
Completed_On varchar(max)

--Step 7 : Update related SF Id's --

select * from [dbo].[Product Types with Pricebook_21-11-17]

select * from [dbo].[Product_Type_Report_21-11-17]

-- update Client_SF_Id
update [dbo].Stromme_Packet_Info
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF1_27_11_17] b
where  [dbo].Stromme_Packet_Info.client_id = b.[Client Code]


select * from Stromme_Packet_Info where Client_SF_Id is null

-- update Pricebook_Id
update [dbo].Stromme_Packet_Info
set Pricebook_Id = c.[Price Book: Record ID]
from [dbo].[Product Types with Pricebook_21-11-17] c
where [dbo].Stromme_Packet_Info.Packet1_SF  = c.[Product Type: ID]

-- update Product_Name
update [dbo].Stromme_Packet_Info
set Product_Name = c.[Product Name]
from [dbo].[Product_Type_Report_21-11-17] c
where [dbo].Stromme_Packet_Info.Packet1_SF = c.[Product Type ID] 

-- update Saving_Goal_Name
update [dbo].Stromme_Packet_Info
set Saving_Goal_Name=CONCAT(client_id,'-2018-',Product_Name)
where Product_Name is not null and Client_SF_Id is not null

select distinct Saving_Goal_Name from Stromme_Packet_Info

-- update ProductId

update Stromme_Packet_Info
set Product_Id = c.[Product ID]
from [dbo].[Product_Type_Report_21-11-17] c
where Stromme_Packet_Info.Packet1_SF = c.[Product Type ID]---5945

-- update Completed_On
update  Stromme_Packet_Info
set Completed_On = convert(varchar(24),cast(b.Completed_time as date),101)
from [dbo].[CRS_29_Dec_17_Prg] b -------- This file is from step 1
where Stromme_Packet_Info.client_id = b.[client-id]

-- Check if Completed_on date is of future then convert it to date before import date
select *
from Stromme_Packet_Info
where completed_on > '12/27/2017'

update Stromme_Packet_Info
set completed_on = '12/26/2017'
where completed_on > '12/27/2017'

--Step 10 : Remove records with Packet_Size = 0 goal items --

/* Note : Source file depends on output of previous file */

select *
into Stromee_Load_PacketSize_0
from Stromme_Packet_Info
where packet1_size = '0' ---  log it as a bug

select *
into Stromee_Load_PacketSize_not_0
from Stromme_Packet_Info
where packet1_size != '0' -- use this file for load



--Step 11 : Dedup savings goals --

select * from Stromee_Load_PacketSize_not_0


select count(Saving_Goal_Name),Saving_Goal_Name
from Stromee_Load_PacketSize_not_0 
group  by Saving_Goal_Name 
having count(Saving_Goal_Name) > 1 ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into Stromee_SG_19Dec_2017 
from Stromee_Load_PacketSize_not_0 

select min(Row) as rw 
into Stromee_SG_Load_Distinct_values
from Stromee_SG_19Dec_2017 
group  by client_id 

Select *
into Stromee_SG_19Dec_2017_Distinct_Records
from Stromee_SG_19Dec_2017
where client_id not in (Select client_id from Stromee_SG_Load_Distinct_values) -- use this file for load

Select *
into Stromee_Dups_from_SG
from Stromee_SG_19Dec_2017
where client_id in (Select client_id from Stromee_SG_Load_Distinct_values) -- export the file and log it as a bug 


--Step 12 : Dedup goal items --

select count(concat(Saving_Goal_Name,Packet1_SF)),concat(Saving_Goal_Name,Packet1_SF) 
from Stromee_Load_PacketSize_not_0 
group  by concat(Saving_Goal_Name,Packet1_SF)
having count(concat(Saving_Goal_Name,Packet1_SF)) > 1

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into Stromee_GI_19dec_2017 
from Stromee_Load_PacketSize_not_0 

select min(Row) as rw 
into Stromee_GI_Load_Distinct_values
from Stromee_GI_19dec_2017 
group  by client_id 

Select *
into Stromee_SG_14Dec_2017_Distinct_Records
from Stromee_GI_19dec_2017
where client_id not in (Select client_id from Stromee_GI_Load_Distinct_values) -- use this file for load

Select *
into SStromee_Dups_from_GI
from Stromee_GI_19dec_2017
where client_id in (Select client_id from Stromee_GI_Load_Distinct_values) -- export the file and log it as a bug 







































