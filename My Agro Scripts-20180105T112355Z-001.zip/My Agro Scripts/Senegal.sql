--Step 1 : Check for the record counts for imported file--

select * from [dbo].[Senegal_14Dec_17]

--Step 2 : Add row number and convert received date to mm/dd/yyyy formats--

select *,
ROW_NUMBER() OVER(ORDER BY [client-id] ASC) AS Row,
convert(varchar(24),cast(received_on as date),101) as Received_Date
into Senegal_Load_14_Dec_17
from [Senegal_14Dec_17]---2915

Select * from Senegal_Load_14_Dec_17--2915

--Step 3 : Remove Duplicates from source file --

select count([client-id]),[client-id]
from Senegal_Load_14_Dec_17 
group  by [client-id] 
having count([client-id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Senegal_Distinct_Values
from Senegal_Load_14_Dec_17 
group  by [client-id] 


Select *
into Senegal_Distinct_Records
from Senegal_Load_14_Dec_17
where [client-id] not in (Select [client-id] from Senegal_Distinct_Values) -- use this file for next step

Select *
into Senegal_Dups_from_source_file
from Senegal_Load_14_Dec_17
where [client-id] in (Select [client-id] from Senegal_Distinct_Values) -- export the file and log it as a bug 


--Step 4 : Remove Duplicates from file which are updated in previous loads--

select count([client-id]),[client-id]
from Senegal_Distinct_Records
group  by [client-id] 
having count([client-id]) > 1  ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select min(Row) as rw 
into Seneal_Distinct_Values_wrt_report
from Senegal_Distinct_Records 
group  by [client-id] 


Select *
into Senegal_Distinct_Records_wrt_report --- use this file for next step
from Senegal_Distinct_Records
where [client-id] not in (Select [Client Code] from Seneal_Distinct_Values_wrt_report)

Select *
into Senegal_Dups_from_reports
from Senegal_Distinct_Records
where [client-id] in (Select [Client Code] from Seneal_Distinct_Values_wrt_report) -- export the file and log it as a bug 


--Step 5 : Discard records out of given date range--

/* Note :  Source file to use here will depend on the output of previous steps */
select * from Senegal_Distinct_Records_wrt_report

SELECT * 
into Senegal_Final_14_12_17
FROM Senegal_Distinct_Records_wrt_report
WHERE Received_Date >= '12/25/2017'---  if no duplicates go to next step and use the source file from previous step

/* Note :  The Received_Date depends on the daily import date. You need to change this as per the requirement. */

--Step 6 : Create Client file --

select a.[client-id] as Client_Id,cast(null as varchar(max)) as Client_SF_Id,
a.[first_name] as First_Name,a.[last_name] as Last_Name ,
a.phone as Phone,
case
When a.gender='M' then 'Male'
When a.gender='F' then 'Female'
When a.gender='Male' then 'Male'
When a.gender='Female' then 'Female'
else '' End As Gender,
[form#village], cast(Null as varchar(max)) as Village_SF_Id ,
convert(varchar(24),cast(a.completed_time as date),101) as Completed_On,completed_time,
[received_on],convert(varchar(24),cast(a.[received_on] as date),101) as Received_Date,row
into Clients_Senegal_14_Dec_17_2988 
from Senegal_Final_14_12_17 a --2840

--Step 7 : Update village Id and Client Id's in Client file --

/* Note  :  We need export the Village data(Village Name, SF Id and Village Code) 
            from SF and need to import file in SQL. Try to populate Village Sf Id's based 
			on village code in source file if you are not getting data then try with village name */ 

update Clients_Senegal_14_Dec_17_2988
set Village_SF_Id = a.id
from [dbo].[Village_SF] a
where a.Village_Code__c = Clients_Senegal_14_Dec_17_2988.form#village --2660


select * from Clients_Senegal_14_Dec_17_2988 where Village_SF_Id is null

/* Note  :  We need export the Clients data(Name and SF Id) 
            from SF and need to import file in SQL */ 

update Clients_Senegal_14_Dec_17_2988
set Client_SF_Id =  a.[Client ID]
from [dbo].CL_SF1_27_11_17 a
where a.[Client Code] = Clients_Senegal_14_Dec_17_2988.Client_Id

/* Check Village_SF_Id and Client_SF_Id for NULL values if 
   this is the case log a bug for blqank villages*/

select * from Clients_Senegal_14_Dec_17_2988 where Client_SF_Id is null

select * from Clients_Senegal_14_Dec_17_2988 where Village_SF_Id is null

--Step 8 : Create Packet files  --

/* Note : use the file created after deduplication of records  */ 

select * from Senegal_Distinct_Records

/* Bissap (Vimto) and Pasteque (Kaolack) have packet size problems problem.
Senegal enrollment: columns named "packet7-size" and "packet8-size"
CRS enrollment: "Packet7-size" and "Packet7-size"
the Bissap packets should all be .225 and the Pasteque should all be .01. */

update Senegal_Distinct_Records
set [packet7-Size] = '0.225'
from Senegal_Distinct_Records
where [packet7-type] = 'Vimto' 

update Senegal_Distinct_Records
set [packet8-Size] = '0.01'
from Senegal_Distinct_Records
where [packet8-type] = 'Kaolack'


SELECT [client-id]
      ,[packet1-SF]
      ,[packet2-sf]
      ,[packet3-sf]
      ,[packet4-sf]
      ,[packet5-sf]
      ,[packet6-sf]
      ,[packet7-sf]
      ,[packet8-sf]
      ,[packet9-sf]
FROM [My Agro].[dbo].Senegal_Distinct_Records ----Create file and load in talend

SELECT [client-id]
      ,[packet1-Size]
      ,[packet2-Size]
      ,[packet3-Size]
      ,[packet4-Size]
      ,[packet5-Size]
      ,[packet6-Size]
      ,[packet7-Size]
      ,[packet8-Size]
      ,[packet9-Size]
FROM [My Agro].[dbo].Senegal_Distinct_Records ----Create file and load in talend

--Step 9 : Create Savings Goal and Goal Items files  --

/* Note : Import the packet file created in talend and use that as a source.
          Export data for pricebook and product report and import the files in SF
		  Use the reports for populating related SF'Ids */ 

select * from [dbo].Senegal_Load_Packet_Info 

update Senegal_Load_Packet_Info
set Packet1_SF = 'a0S0J00000RdEmt'
where Packet1_SF = 'a0M0J00001BhbCk'

alter table Senegal_Load_Packet_Info
add Product_Id varchar(max),
Product_Name varchar(max),
Client_SF_Id varchar(max),
Pricebook_Id varchar(max),
Saving_Goal_Name varchar(max),
Completed_On varchar(max)

--Step 7 : Update related SF Id's --

select * from [dbo].[Product Types with Pricebook_21-11-17]

select * from [dbo].[Product_Type_Report_21-11-17]

-- update Client_SF_Id
update [dbo].Senegal_Load_Packet_Info
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF1_27_11_17] b
where  [dbo].Senegal_Load_Packet_Info.client_id = b.[Client Code]


select * from Senegal_Load_Packet_Info where Client_SF_Id is null

-- update Pricebook_Id
update [dbo].Senegal_Load_Packet_Info
set Pricebook_Id = c.[Price Book: Record ID]
from [dbo].[Product Types with Pricebook_21-11-17] c
where [dbo].Senegal_Load_Packet_Info.Packet1_SF  = c.[Product Type: ID]

-- update Product_Name
update [dbo].Senegal_Load_Packet_Info
set Product_Name = c.[Product Name]
from [dbo].[Product_Type_Report_21-11-17] c
where [dbo].Senegal_Load_Packet_Info.Packet1_SF = c.[Product Type ID] 

-- update Saving_Goal_Name
update [dbo].Senegal_Load_Packet_Info
set Saving_Goal_Name=CONCAT(client_id,'-2018-',Product_Name)
where Product_Name is not null and Client_SF_Id is not null

select distinct Saving_Goal_Name from Senegal_Load_Packet_Info

-- update ProductId

update Senegal_Load_Packet_Info
set Product_Id = c.[Product ID]
from [dbo].[Product_Type_Report_21-11-17] c
where Senegal_Load_Packet_Info.Packet1_SF = c.[Product Type ID]---5945

-- update Completed_On
update  Senegal_Load_Packet_Info
set Completed_On = convert(varchar(24),cast(b.Completed_time as date),101)
from [dbo].[Senegal_14Dec_17] b -------- This file is from step 1
where Senegal_Load_Packet_Info.client_id = b.[client-id]

-- Check if Completed_on date is of future then convert it to date before import date
select *
from Senegal_Load_Packet_Info
where completed_on > '12/27/2017'

update Senegal_Load_Packet_Info
set completed_on = '12/26/2017'
where completed_on > '12/27/2017'


--Step 10 : Remove records with Packet_Size = 0 goal items --

/* Note : Source file depends on output of previous file */

select *
into Senegal_Load_PacketSize_0
from Senegal_Load_Packet_Info
where packet1_size = '0' ---  log it as a bug

select *
into Senegal_Load_PacketSize_not_0
from Senegal_Load_Packet_Info
where packet1_size != '0' -- use this file for load



--Step 11 : Dedup savings goals --

select * from Senegal_Load_Packet_Info


select count(Saving_Goal_Name),Saving_Goal_Name
from Senegal_Load_PacketSize_not_0 
group  by Saving_Goal_Name 
having count(Saving_Goal_Name) > 1 ----- if no duplicates go to next step and use the source file from previous step

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into Senegal_SG_14Dec_2017 
from Senegal_Load_PacketSize_not_0 

select min(Row) as rw 
into Senegal_SG_Load_Distinct_values
from Senegal_SG_14Dec_2017 
group  by client_id 

Select *
into Senegal_SG_14Dec_2017_Distinct_Records
from Senegal_SG_14Dec_2017
where client_id not in (Select client_id from Senegal_SG_Load_Distinct_values) -- use this file for load

Select *
into Senegal_Dups_from_SG
from Senegal_SG_14Dec_2017
where client_id in (Select client_id from Senegal_SG_Load_Distinct_values) -- export the file and log it as a bug 


--Step 12 : Dedup goal items --

select count(concat(Saving_Goal_Name,Packet1_SF)),concat(Saving_Goal_Name,Packet1_SF) 
from Senegal_Load_PacketSize_not_0 
group  by concat(Saving_Goal_Name,Packet1_SF)
having count(concat(Saving_Goal_Name,Packet1_SF)) > 1

/* If the above query gives you duplicates then only follow following steps */

select *, 
ROW_NUMBER() OVER(ORDER BY client_id ASC) AS Row
into Senegal_GI_14dec_2017 
from Senegal_Load_PacketSize_not_0 

select min(Row) as rw 
into Snegal_GI_Load_Distinct_values
from Senegal_GI_14dec_2017 
group  by client_id 

Select *
into Senegal_SG_14Dec_2017_Distinct_Records
from Senegal_GI_14dec_2017
where client_id not in (Select client_id from Snegal_GI_Load_Distinct_values) -- use this file for load

Select *
into Senegal_Dups_from_GI
from Senegal_GI_14dec_2017
where client_id in (Select client_id from Snegal_GI_Load_Distinct_values) -- export the file and log it as a bug 





























--------------------------------------------------------------------


-----	Wherever the packet id is a0M0J00001BhbCk, replace with id a0S0J00000RdEmt
select * from [dbo].[Packet_Info_Senegal_14Dec_17] ---3606 

alter table [Packet_Info_Senegal_14Dec_17]
add Product_Id varchar(max),
Product_Name varchar(max),
Client_SF_Id varchar(max),
Pricebook_Id varchar(max),
Saving_Goal_Name varchar(max),
Completed_On varchar(max)

--------------update Client_SF_Id---------------
update [dbo].[Packet_Info_Senegal_14Dec_17]
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF1_27_11_17] b
where  [dbo].[Packet_Info_Senegal_14Dec_17].client_id = b.[Client Code]-- 1540 + 

update [dbo].[Packet_Info_Senegal_14Dec_17]
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF2_27_11_17] b
where  [dbo].[Packet_Info_Senegal_14Dec_17].client_id = b.[Client Code] --1875


update [dbo].[Packet_Info_Senegal_14Dec_17]
set Client_SF_Id = b.[Client ID]
from [dbo].[CL_SF3_27-11-17] b
where  [dbo].[Packet_Info_Senegal_14Dec_17].client_id = b.[Client Code] --2033

select * from [Packet_Info_Senegal_14Dec_17] where Client_SF_Id is null



--------------update Pricebook_Id---------------
update [dbo].[Packet_Info_Senegal_14Dec_17]
set Pricebook_Id = c.[Price Book: Record ID]
from [dbo].[Product Types with Pricebook_21-11-17] c
where [dbo].[Packet_Info_Senegal_14Dec_17].Packet1_SF  = c.[Product Type: ID] ---3603

select * from [dbo].[Product Types with Pricebook_21-11-17]

select * from [dbo].[Product_Type_Report_21-11-17]

--------------update Product_Name---------------
update [dbo].[Packet_Info_Senegal_14Dec_17]
set Product_Name = c.[Product Name]
from [dbo].[Product_Type_Report_21-11-17] c
where [dbo].[Packet_Info_Senegal_14Dec_17].Packet1_SF = c.[Product Type ID] --3603

--------------update Saving_Goal_Name---------------
update [dbo].[Packet_Info_Senegal_14Dec_17]
set Saving_Goal_Name=CONCAT(client_id,'-2018-',Product_Name)
where Product_Name is not null  ----3603


----------------------update ProductId---------------------------

update [Packet_Info_Senegal_14Dec_17]
set Product_Id = c.[Product ID]
from [dbo].[Product_Type_Report_21-11-17] c
where [Packet_Info_Senegal_14Dec_17].Packet1_SF = c.[Product Type ID]---5945

----------------------update Completed on---------------------------

update  [Packet_Info_Senegal_14Dec_17]
set Completed_On = convert(varchar(24),cast(Completed_time as date),101)
from [Senegal_14Dec_17] b
where [Packet_Info_Senegal_14Dec_17].client_id = b.[client-id]  ----3603

----- Implementation
All 4 scripts need to be updated to change the enrollment date of goal items that are in the future to the date before the upload date.
Acceptance Criteria
Any enrollment date in the future is changed to the date before the upload date. -----

select distinct Completed_On from 
Clients_Mali_20_Dec_17_1733
where Completed_On > '12/20/2017' ----chnage to one day before import if exists 

------------------------------dedup SG----------------------------------------------------

select * from [Packet_Info_Senegal_14Dec_17]

	select count(Saving_Goal_Name),concat(Saving_Goal_Name,Packet1_SF)
	---into Mali_Distinct_Values
	from [Packet_Info_Senegal_14Dec_17] 
	group  by concat(Saving_Goal_Name,Packet1_SF)
	having count(Saving_Goal_Name) = 1---duplicates


